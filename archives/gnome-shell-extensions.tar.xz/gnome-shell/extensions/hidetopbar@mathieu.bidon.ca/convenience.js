/**
 * This file is part of Hide Top Bar
 *
 * Copyright 2020 Thomas Vogt
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import Meta from 'gi://Meta';

export const LOG = function (message) {
    console.log(`[hidetopbar] ${message}`);
};

export const DEBUG = function (message) {
    console.log(`[hidetopbar DEBUG] ${message}`);
};

export const WARN = function (message, err) {
    if (err) {
        console.warn(`[hidetopbar WARNING] ${message}:`, err);
    } else {
        console.warn(`[hidetopbar WARNING] ${message}`);
    }
};

export const ERROR = function (message, err) {
    if (err) {
        console.error(`[hidetopbar ERROR] ${message}:`, err);
        if (err.stack) {
            console.error(`[hidetopbar STACK] ${err.stack}`);
        }
    } else {
        console.error(`[hidetopbar ERROR] ${message}`);
    }
};

// try to simplify global signals handling
export class GlobalSignalsHandler {
    constructor() {
        this._signals = new Object();
    }

    add(/*unlimited 3-long array arguments*/){
        this._addSignals('generic', arguments);
    }

    destroy() {
        for( let label in this._signals )
            this.disconnectWithLabel(label);
    }

    addWithLabel(label /* plus unlimited 3-long array arguments*/) {
        // skip first element of the arguments array;
        let elements = new Array;
        for(let i = 1 ; i < arguments.length; i++)
            elements.push(arguments[i]);
        this._addSignals(label, elements);
    }

    _addSignals(label, elements) {
        if(this._signals[label] == undefined)
            this._signals[label] = new Array();
        for( let i = 0; i < elements.length; i++ ) {
            try {
                let object = elements[i][0];
                let event = elements[i][1];
                let callback = elements[i][2];
                if (!object) {
                    WARN(`Cannot connect signal '${event}' for label '${label}': target object is null/undefined`);
                    continue;
                }
                let id = object.connect(event, callback);
                this._signals[label].push( [ object , id, event ] );
            } catch (err) {
                ERROR(`Failed to connect signal for label '${label}'`, err);
            }
        }
    }

    disconnectWithLabel(label) {
        if(this._signals[label]) {
            for( let i = 0; i < this._signals[label].length; i++ ) {
                try {
                    let [object, id, event] = this._signals[label][i];
                    if (object && id) {
                        object.disconnect(id);
                    }
                } catch (err) {
                    WARN(`Failed to disconnect signal for label '${label}'`, err);
                }
            }
            delete this._signals[label];
        }
    }
};

export function getMonitorManager() {
    try {
        if (global.backend && global.backend.get_monitor_manager !== undefined)
            return global.backend.get_monitor_manager();
        else if (Meta.MonitorManager && Meta.MonitorManager.get)
            return Meta.MonitorManager.get();
    } catch (err) {
        ERROR('Failed to get monitor manager', err);
    }
    return null;
}

