/**
 * This file is part of Hide Top Bar
 *
 * Copyright 2020 Thomas Vogt
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

// Note that the code in this file is taken from the Dash to Dock Gnome Shell
// extension (https://github.com/micheleg/dash-to-dock) with only minor
// modifications. Dash to Dock is distributed under the terms of the GNU
// General Public License, version 2 or later.

import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Signals from 'resource:///org/gnome/shell/misc/signals.js';

import * as Convenience from './convenience.js';
const { DEBUG, LOG, WARN, ERROR } = Convenience;

// A good compromise between reactivity and efficiency; to be tuned.
export const INTELLIHIDE_CHECK_INTERVAL = 100;

export const OverlapStatus = {
    UNDEFINED: -1,
    FALSE: 0,
    TRUE: 1
};

export const IntellihideMode = {
    ALL_WINDOWS: 0,
    FOCUS_APPLICATION_WINDOWS: 1,
    MAXIMIZED_WINDOWS : 2
};

// List of windows type taken into account. Order is important (keep the
// original enum order).
export const handledWindowTypes = [
    Meta.WindowType.NORMAL,
    Meta.WindowType.DOCK,
    Meta.WindowType.DIALOG,
    Meta.WindowType.MODAL_DIALOG,
    Meta.WindowType.TOOLBAR,
    Meta.WindowType.MENU,
    Meta.WindowType.UTILITY,
    Meta.WindowType.SPLASHSCREEN
];

/**
 * An implementation of the intellihide behaviour.
 * Intellihide object: emit 'status-changed' signal when the overlap of windows
 * with the provided targetBox Clutter.ActorBox changes;
 */
export class Intellihide extends Signals.EventEmitter {

    constructor(settings, monitorIndex) {
        super();

        // Load settings
        this._settings = settings;
        this._monitorIndex = monitorIndex;

        this._signalsHandler = new Convenience.GlobalSignalsHandler();
        this._tracker = Shell.WindowTracker.get_default();

        // The application whose window is focused.
        this._focusApp = null;

        // The application whose window is on top on the monitor with the panel.
        this._topApp = null;

        this._isEnabled = false;
        this._status = OverlapStatus.UNDEFINED;
        this._targetBox = null;

        this._checkOverlapTimeoutContinue = false;
        this._checkOverlapTimeoutId = 0;

        this._trackedWindows = new Map();

        try {
            // Connect global signals
            let monitorManager = Convenience.getMonitorManager();
            let signals = [
                // Listen for notification banners to appear or disappear
                [
                    Main.messageTray,
                    'show',
                    this._checkOverlap.bind(this)
                ], [
                    Main.messageTray,
                    'hide',
                    this._checkOverlap.bind(this)
                ], [
                    // Add signals on windows created from now on
                    global.display,
                    'window-created',
                    this._windowCreated.bind(this)
                ], [
                    // triggered when the window list order changes
                    global.display,
                    'restacked',
                    this._checkOverlap.bind(this)
                ], [
                    // triggered when a window is minimized, unminimized, hidden or shown
                    global.display,
                    'window-visibility-updated',
                    this._checkOverlap.bind(this)
                ], [
                    // triggered when a window enters or exits fullscreen
                    global.display,
                    'in-fullscreen-changed',
                    this._checkOverlap.bind(this)
                ], [
                    // triggered when a window enters or leaves the monitor
                    global.display,
                    'window-entered-monitor',
                    this._checkOverlap.bind(this)
                ], [
                    global.display,
                    'window-left-monitor',
                    this._checkOverlap.bind(this)
                ], [
                    // triggered when keyboard focus moves between windows (even within same app)
                    global.display,
                    'focus-window',
                    this._checkOverlap.bind(this)
                ], [
                    // monitor active application changes
                    this._tracker,
                    'notify::focus-app',
                    this._checkOverlap.bind(this)
                ], [
                    // active workspace changed (switching workspaces)
                    global.workspace_manager,
                    'active-workspace-changed',
                    this._checkOverlap.bind(this)
                ], [
                    // desktop shown or hidden (e.g. Super+D)
                    global.workspace_manager,
                    'showing-desktop-changed',
                    this._checkOverlap.bind(this)
                ]
            ];

            if (monitorManager) {
                signals.push([
                    monitorManager,
                    'monitors-changed',
                    this._checkOverlap.bind(this)
                ]);
            }

            this._signalsHandler.add(...signals);
        } catch (err) {
            ERROR("Failed to connect signals in Intellihide constructor", err);
        }
    }

    destroy() {
        try {
            // Disconnect global signals
            this._signalsHandler.destroy();

            // Remove residual windows signals
            this.disable();
        } catch (err) {
            ERROR("Error destroying Intellihide", err);
        }
    }

    enable() {
        try {
            this._isEnabled = true;
            this._status = OverlapStatus.UNDEFINED;
            let windowActors = global.get_window_actors ? global.get_window_actors() : [];
            windowActors.forEach((wa) => {
                this._addWindowSignals(wa);
            });
            this._doCheckOverlap();
        } catch (err) {
            ERROR("Error enabling Intellihide", err);
        }
    }

    disable() {
        try {
            this._isEnabled = false;

            for (let wa of this._trackedWindows.keys()) {
                this._removeWindowSignals(wa);
            }
            this._trackedWindows.clear();

            if (this._checkOverlapTimeoutId > 0) {
                GLib.source_remove(this._checkOverlapTimeoutId);
                this._checkOverlapTimeoutId = 0;
            }
        } catch (err) {
            ERROR("Error disabling Intellihide", err);
        }
    }

    _windowCreated(display, metaWindow) {
        try {
            if (!metaWindow) return;
            let wa = metaWindow.get_compositor_private ? metaWindow.get_compositor_private() : null;
            if (wa) {
                this._addWindowSignals(wa);
            }
        } catch (err) {
            ERROR("Error in _windowCreated", err);
        }
    }

    _addWindowSignals(wa) {
        try {
            if (!wa || !this._handledWindow(wa))
                return;
            if (this._trackedWindows.has(wa))
                return;

            let metaWindow = wa.get_meta_window ? wa.get_meta_window() : null;

            let signalId = wa.connect(
                'notify::allocation', this._checkOverlap.bind(this)
            );
            let visibleId = wa.connect(
                'notify::visible', this._checkOverlap.bind(this)
            );
            let destroyId = wa.connect('destroy', () => {
                this._removeWindowSignals(wa);
                this._checkOverlap();
            });

            let winWorkspaceId = null;
            let winUnmanagedId = null;
            if (metaWindow) {
                try {
                    winWorkspaceId = metaWindow.connect('workspace-changed', this._checkOverlap.bind(this));
                } catch (e) {}
                try {
                    winUnmanagedId = metaWindow.connect('unmanaged', this._checkOverlap.bind(this));
                } catch (e) {}
            }

            this._trackedWindows.set(wa, {
                signalId,
                visibleId,
                destroyId,
                metaWindow,
                winWorkspaceId,
                winUnmanagedId
            });
        } catch (err) {
            ERROR("Error in _addWindowSignals", err);
        }
    }

    _removeWindowSignals(wa) {
        try {
            let data = this._trackedWindows.get(wa);
            if (data) {
                if (data.signalId) {
                    try { wa.disconnect(data.signalId); } catch (e) {}
                }
                if (data.visibleId) {
                    try { wa.disconnect(data.visibleId); } catch (e) {}
                }
                if (data.destroyId) {
                    try { wa.disconnect(data.destroyId); } catch (e) {}
                }
                if (data.metaWindow) {
                    if (data.winWorkspaceId) {
                        try { data.metaWindow.disconnect(data.winWorkspaceId); } catch (e) {}
                    }
                    if (data.winUnmanagedId) {
                        try { data.metaWindow.disconnect(data.winUnmanagedId); } catch (e) {}
                    }
                }
                this._trackedWindows.delete(wa);
            }
        } catch (err) {
            WARN("Error in _removeWindowSignals", err);
        }
    }

    updateTargetBox(box) {
        try {
            this._targetBox = box;
            this._checkOverlap();
        } catch (err) {
            ERROR("Error in updateTargetBox", err);
        }
    }

    forceUpdate() {
        try {
            this._status = OverlapStatus.UNDEFINED;
            this._doCheckOverlap();
        } catch (err) {
            ERROR("Error in forceUpdate", err);
        }
    }

    getOverlapStatus() {
        return (this._status == OverlapStatus.TRUE);
    }

    _checkOverlap() {
        try {
            if (!this._isEnabled || (this._targetBox == null))
                return;

            /* Limit the number of calls to the doCheckOverlap function */
            if (this._checkOverlapTimeoutId) {
                this._checkOverlapTimeoutContinue = true;
                return;
            }

            this._doCheckOverlap();

            this._checkOverlapTimeoutId = GLib.timeout_add(
                GLib.PRIORITY_DEFAULT, INTELLIHIDE_CHECK_INTERVAL, () => {
                try {
                    this._doCheckOverlap();
                    if (this._checkOverlapTimeoutContinue) {
                        this._checkOverlapTimeoutContinue = false;
                        return GLib.SOURCE_CONTINUE;
                    } else {
                        this._checkOverlapTimeoutId = 0;
                        return GLib.SOURCE_REMOVE;
                    }
                } catch (err) {
                    ERROR("Error in _checkOverlap timeout loop", err);
                    this._checkOverlapTimeoutId = 0;
                    return GLib.SOURCE_REMOVE;
                }
            });
        } catch (err) {
            ERROR("Error in _checkOverlap", err);
        }
    }

    _doCheckOverlap() {
        try {
            if (!this._isEnabled || (this._targetBox == null))
                return;

            let overlaps = OverlapStatus.FALSE;
            let windows = global.get_window_actors ? global.get_window_actors() : [];

            if (windows.length > 0) {
                let topWindow = null;
                for (let i = windows.length - 1; i >= 0; i--) {
                    if (!windows[i]) continue;
                    let meta_win = windows[i].get_meta_window();
                    if (
                        meta_win
                        && this._handledWindow(windows[i])
                        && (meta_win.get_monitor() == this._monitorIndex)
                        && !meta_win.minimized
                        && !meta_win.is_hidden()
                        && meta_win.showing_on_its_workspace()
                    ) {
                        topWindow = meta_win;
                        break;
                    }
                }

                if (topWindow !== null) {
                    this._topApp = this._tracker.get_window_app(topWindow);
                    // If there isn't a focused app, use that of the window on top
                    this._focusApp = this._tracker.focus_app || this._topApp;

                    windows = windows.filter(
                        this._intellihideFilterInteresting, this,
                    );

                    for (let i = 0; i < windows.length; i++) {
                        let win = windows[i] ? windows[i].get_meta_window() : null;

                        if (win) {
                            let rect = win.get_frame_rect();
                            if (rect && !isNaN(rect.x) && !isNaN(rect.y) && !isNaN(rect.width) && !isNaN(rect.height) && rect.width > 0 && rect.height > 0) {
                                let test = (rect.x < this._targetBox.x2) &&
                                           (rect.x + rect.width > this._targetBox.x1) &&
                                           (rect.y < this._targetBox.y2) &&
                                           (rect.y + rect.height > this._targetBox.y1);

                                if (test) {
                                    overlaps = OverlapStatus.TRUE;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            if (this._status !== overlaps) {
                this._status = overlaps;
                this.emit('status-changed', this._status);
            }
        } catch (err) {
            ERROR("Error in _doCheckOverlap", err);
        }
    }

    // Filter interesting windows to be considered for intellihide.
    // Consider all windows visible on the current workspace.
    // Optionally skip windows of other applications
    _intellihideFilterInteresting(wa) {
        try {
            if (!wa) return false;
            let meta_win = wa.get_meta_window();
            if (!meta_win || !this._handledWindow(wa))
                return false;

            if (meta_win.minimized || meta_win.is_hidden())
                return false;

            let currentWorkspace = (
                global.workspace_manager.get_active_workspace_index()
            );
            let wksp = meta_win.get_workspace();
            if (!wksp) return false;
            let wksp_index = wksp.index();

            // Depending on the intellihide mode, exclude non-relevant windows
            if (this._settings.get_boolean('enable-active-window')) {
                // Skip windows of other apps
                if (this._focusApp) {
                    if (meta_win.get_wm_class && meta_win.get_wm_class() == 'DropDownTerminalWindow')
                        return true;

                    let currentApp = this._tracker.get_window_app(meta_win);
                    let focusWindow = global.display.get_focus_window();

                    // Consider half maximized windows side by side
                    // and windows which are always on top
                    if(
                        (currentApp != this._focusApp)
                        && (currentApp != this._topApp)
                        && !(
                            focusWindow
                            && focusWindow.maximized_vertically
                            && !focusWindow.maximized_horizontally
                            && meta_win.maximized_vertically
                            && !meta_win.maximized_horizontally
                            && (
                                meta_win.get_monitor()
                                == focusWindow.get_monitor()
                            )
                        )
                        && !meta_win.is_above()
                    ) {
                        return false;
                    }
                }
            }

            if (
                wksp_index == currentWorkspace
                && meta_win.showing_on_its_workspace()
            ) {
                return true;
            } else {
                return false;
            }
        } catch (err) {
            WARN("Error filtering window for intellihide", err);
            return false;
        }
    }

    // Filter windows by type
    _handledWindow(wa) {
        try {
            if (!wa) return false;
            let metaWindow = wa.get_meta_window();

            if (!metaWindow)
                return false;

            const ignoreApps = [ "com.rastersoft.ding", "com.desktop.ding" ];
            const wmApp = metaWindow.get_gtk_application_id ? metaWindow.get_gtk_application_id() : null;
            if (wmApp && ignoreApps.includes(wmApp) && metaWindow.is_skip_taskbar())
                return false;

            if (metaWindow.get_wm_class && metaWindow.get_wm_class() == 'DropDownTerminalWindow')
                return true;

            let wtype = metaWindow.get_window_type();
            for (let i = 0; i < handledWindowTypes.length; i++) {
                let hwtype = handledWindowTypes[i];
                if (hwtype == wtype)
                    return true;
                else if (hwtype > wtype)
                    return false;
            }
            return false;
        } catch (err) {
            WARN("Error checking handled window", err);
            return false;
        }
    }
};
