/**
 * This file is part of Hide Top Bar
 *
 * Copyright 2020 Thomas Vogt
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import Clutter from 'gi://Clutter';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Layout from 'resource:///org/gnome/shell/ui/layout.js';
import * as Config from 'resource:///org/gnome/shell/misc/config.js';
import * as PointerWatcher from 'resource:///org/gnome/shell/ui/pointerWatcher.js';
const [major] = Config.PACKAGE_VERSION.split('.');
const shellVersion = Number.parseInt(major);

import * as Convenience from './convenience.js';
import * as Intellihide from './intellihide.js';
import * as DesktopIconsIntegration from './desktopIconsIntegration.js';
const { DEBUG, LOG, WARN, ERROR } = Convenience;

const MessageTray = Main.messageTray;
const PanelBox = Main.layoutManager.panelBox;
const ShellActionMode = (
    Shell.ActionMode ? Shell.ActionMode : Shell.KeyBindingMode
);

function getSearchEntryBin() {
    try {
        return Main.overview?._overview?._controls?._searchEntryBin
            ?? Main.overview?._controls?._searchEntryBin
            ?? null;
    } catch (err) {
        return null;
    }
}

export class PanelVisibilityManager {

    _getBaseY() {
        return Main.layoutManager.primaryMonitor ? Main.layoutManager.primaryMonitor.y : 0;
    }

    constructor(settings, monitorIndex) {
        this._monitorIndex = monitorIndex;
        this._settings = settings;
        this._preventHide = false;
        this._showInOverview = true;
        this._intellihideBlock = false;
        this._staticBox = new Clutter.ActorBox();
        this._animationActive = false;
        this._shortcutTimeout = null;
        this._pointerListener = null;
        this._bindTimeoutId = 0;
        this._oldEase = null;
        this._origStartSwitcher = null;
        this._origToggleQuickSettings = null;
        this._origToggleCalendar = null;
        this._origDashAdjustIconSize = null;
        this._signalsHandler = new Convenience.GlobalSignalsHandler();

        // Safety guard: if an Alt+Tab or switcher allocation fails (e.g. from invalid clone sizing or theme NaN),
        // intercept the error and ensure the modal grab is safely released so GNOME Shell doesn't freeze.
        try {
            if (Main.wm && typeof Main.wm._startSwitcher === 'function') {
                this._origStartSwitcher = Main.wm._startSwitcher;
                Main.wm._startSwitcher = (...args) => {
                    try {
                        return this._origStartSwitcher.apply(Main.wm, args);
                    } catch (err) {
                        ERROR("Exception intercepted in Main.wm._startSwitcher", err);
                        try {
                            if (Main.modalActorFocusStack && Main.modalActorFocusStack.length > 0) {
                                let topModal = Main.modalActorFocusStack[Main.modalActorFocusStack.length - 1];
                                if (topModal && topModal.actor) {
                                    WARN("Destroying stuck modal actor to recover session");
                                    topModal.actor.destroy();
                                }
                            }
                        } catch (cleanErr) {
                            ERROR("Failed to clean up stuck modal grab", cleanErr);
                        }
                    }
                };
            }
        } catch (err) {
            WARN("Could not install switcher safety guard", err);
        }

        try {
            this._desktopIconsUsableArea = (
                new DesktopIconsIntegration.DesktopIconsUsableAreaClass()
            );
        } catch (err) {
            WARN("Failed to initialize DesktopIconsIntegration", err);
            this._desktopIconsUsableArea = null;
        }

        try {
            Main.layoutManager.removeChrome(PanelBox);
            Main.layoutManager.addChrome(PanelBox, {
                affectsStruts: false,
                trackFullscreen: true
            });
        } catch (err) {
            ERROR("Failed to update PanelBox chrome", err);
        }

        // We lost the original notification's position because of
        // PanelBox->affectsStruts = false and now it appears beneath the
        // top bar, fix it
        try {
            if (MessageTray && MessageTray._bannerBin && typeof MessageTray._bannerBin.ease === 'function') {
                this._oldEase = MessageTray._bannerBin.ease;
                MessageTray._bannerBin.ease = (
                    function(params) {
                        try {
                            if (params && params.hasOwnProperty("y") && PanelBox && PanelBox.y >= 0) {
                                params.y += PanelBox.height;
                            }
                        } catch (e) {
                            WARN("Error adjusting bannerBin ease y", e);
                        }
                        if (this._oldEase) {
                            return this._oldEase.apply(MessageTray._bannerBin, arguments);
                        }
                    }
                ).bind(this);
            }
        } catch (err) {
            WARN("Failed to patch MessageTray bannerBin ease", err);
        }

        try {
            this._pointerWatcher = PointerWatcher.getPointerWatcher();
        } catch (err) {
            ERROR("Failed to get PointerWatcher", err);
            this._pointerWatcher = null;
        }

        // Load settings
        this._bindSettingsChanges();
        this._updateSettingsMouseSensitive();
        this._updateSettingsShowInOverview();
        try {
            this._intellihide = new Intellihide.Intellihide(
                this._settings, this._monitorIndex,
            );
        } catch (err) {
            ERROR("Failed to initialize Intellihide", err);
            this._intellihide = null;
        }

        this._updateHotCorner(false);
        this._updateStaticBox();

        // Ensure Super+S (Quick Settings) and Super+M (Calendar) work seamlessly when the top bar is hidden
        try {
            if (Main.panel) {
                this._origToggleQuickSettings = Main.panel.toggleQuickSettings;
                Main.panel.toggleQuickSettings = () => {
                    LOG("Main.panel.toggleQuickSettings() triggered");
                    this.show(0, "quick-settings");
                    let indicator = Main.panel.statusArea?.quickSettings;
                    if (indicator && indicator.menu) {
                        indicator.menu.toggle();
                        if (indicator.menu.isOpen && indicator.menu.actor) {
                            try {
                                indicator.menu.actor.navigate_focus(null, 1, false);
                            } catch (e) {}
                        }
                    } else if (this._origToggleQuickSettings) {
                        this._origToggleQuickSettings.call(Main.panel);
                    }
                };

                this._origToggleCalendar = Main.panel.toggleCalendar;
                Main.panel.toggleCalendar = () => {
                    LOG("Main.panel.toggleCalendar() triggered");
                    this.show(0, "calendar");
                    let indicator = Main.panel.statusArea?.dateMenu;
                    if (indicator && indicator.menu) {
                        indicator.menu.toggle();
                        if (indicator.menu.isOpen && indicator.menu.actor) {
                            try {
                                indicator.menu.actor.navigate_focus(null, 1, false);
                            } catch (e) {}
                        }
                    } else if (this._origToggleCalendar) {
                        this._origToggleCalendar.call(Main.panel);
                    }
                };
            }

            if (Main.wm) {
                if (typeof Main.wm._toggleQuickSettings === 'function') {
                    this._origWmToggleQuickSettings = Main.wm._toggleQuickSettings;
                    Main.wm._toggleQuickSettings = () => {
                        LOG("Main.wm._toggleQuickSettings() triggered");
                        this.show(0, "quick-settings");
                        let indicator = Main.panel?.statusArea?.quickSettings;
                        if (indicator && indicator.menu) {
                            indicator.menu.toggle();
                            if (indicator.menu.isOpen && indicator.menu.actor) {
                                try {
                                    indicator.menu.actor.navigate_focus(null, 1, false);
                                } catch (e) {}
                            }
                        } else if (this._origWmToggleQuickSettings) {
                            this._origWmToggleQuickSettings.call(Main.wm);
                        }
                    };
                }

                if (typeof Main.wm._toggleCalendar === 'function') {
                    this._origWmToggleCalendar = Main.wm._toggleCalendar;
                    Main.wm._toggleCalendar = () => {
                        LOG("Main.wm._toggleCalendar() triggered");
                        this.show(0, "calendar");
                        let indicator = Main.panel?.statusArea?.dateMenu;
                        if (indicator && indicator.menu) {
                            indicator.menu.toggle();
                            if (indicator.menu.isOpen && indicator.menu.actor) {
                                try {
                                    indicator.menu.actor.navigate_focus(null, 1, false);
                                } catch (e) {}
                            }
                        } else if (this._origWmToggleCalendar) {
                            this._origWmToggleCalendar.call(Main.wm);
                        }
                    };
                }
            }
        } catch (err) {
            WARN("Failed to install toggleQuickSettings hook", err);
        }

        // Apply dash size polish to prevent gigantic icons in the overview
        this._applyDashPolish();

        this._bindTimeoutId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT, 100, this._bindUIChanges.bind(this),
        );
    }

    hide(animationTime, trigger) {
        try {
            DEBUG("hide(" + trigger + ")");
            if(this._preventHide) return;

            let base_y = this._getBaseY();
            let height = PanelBox.height || Main.panel.height || 32;
            let anchor_y = PanelBox.get_pivot_point()[1];
            let delta_y = -height;
            if(anchor_y < 0) delta_y = -delta_y;
            let mouse = global.get_pointer();
            if(trigger == "mouse-left" && this._isHovering(...mouse)) return;

            if(this._pointerListener && this._pointerWatcher) {
                try {
                    this._pointerWatcher._removeWatch(this._pointerListener);
                } catch (e) {
                    WARN("Failed to remove pointer watcher listener in hide", e);
                }
                this._pointerListener = null;
            }

            if(this._animationActive) {
                try {
                    PanelBox.remove_all_transitions();
                } catch (e) {}
                this._animationActive = false;
            }

            this._animationActive = true;
            PanelBox.ease({
                y: base_y + delta_y,
                duration: Math.max(0, animationTime * 1000),
                mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                onComplete: () => {
                    try {
                        if (!this._settings.get_boolean('keep-round-corners')) {
                            PanelBox.hide();
                        }
                        this._updateHotCorner(true);
                    } catch (err) {
                        ERROR("Error in hide onComplete", err);
                    } finally {
                        this._animationActive = false;
                    }
                },
                onStopped: () => {
                    this._animationActive = false;
                }
            });
        } catch (err) {
            this._animationActive = false;
            ERROR("Error in hide()", err);
        }
    }

    show(animationTime, trigger) {
        try {
            DEBUG("show(" + trigger + ")");
            if(trigger == "mouse-enter"
               && this._settings.get_boolean('mouse-triggers-overview')) {
                try {
                    Main.overview.show();
                } catch (e) {
                    ERROR("Failed to show overview on mouse-enter", e);
                }
            }

            if(this._animationActive) {
                try {
                    PanelBox.remove_all_transitions();
                } catch (e) {}
                this._animationActive = false;
            }

            this._updateHotCorner(false);
            PanelBox.show();
            let base_y = this._getBaseY();
            let height = PanelBox.height || Main.panel.height || 32;
            if(trigger == "destroy"
               || (
                   trigger == "showing-overview"
                   && global.get_pointer()[1] < height
                   && this._settings.get_boolean('hot-corner')
                  )
              ) {
                PanelBox.y = base_y;
            } else {
                this._animationActive = true;
                PanelBox.ease({
                    y: base_y,
                    duration: Math.max(0, animationTime * 1000),
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                    onComplete: () => {
                        try {
                            this._updateStaticBox();

                            const mouse = global.get_pointer();

                            if(!this._isHovering(...mouse))
                            {
                                this._handleMenus();
                            }
                            else if(!this._pointerListener && this._pointerWatcher)
                            {
                                this._pointerListener =
                                    this._pointerWatcher.addWatch
                                        (10, this._handlePointer.bind(this));
                            }
                        } catch (err) {
                            ERROR("Error in show onComplete", err);
                        } finally {
                            this._animationActive = false;
                        }
                    },
                    onStopped: () => {
                        this._animationActive = false;
                    }
                });
            }
        } catch (err) {
            this._animationActive = false;
            ERROR("Error in show()", err);
        }
    }

    _isHovering(x, y) {
        try {
            return (    y >= this._staticBox.y1 &&
                        y < this._staticBox.y2 &&
                        x >= this._staticBox.x1 &&
                        x < this._staticBox.x2 );
        } catch (err) {
            return false;
        }
    }

    _handlePointer(x, y) {
        try {
            if(!this._animationActive && !this._isHovering(x, y)) {
                this._handleMenus();
            }
        } catch (err) {
            ERROR("Error in _handlePointer", err);
        }
    }

    _handleMenus() {
        try {
            if(!Main.overview.visible) {
                let blocker = Main.panel.menuManager?.activeMenu;
                if(blocker == null) {
                    this.hide(
                        this._settings.get_double('animation-time-autohide'),
                        "mouse-left"
                    );
                } else {
                    if (this._blockerMenu && this._menuEvent) {
                        try {
                            this._blockerMenu.disconnect(this._menuEvent);
                        } catch (e) {}
                        this._menuEvent = null;
                        this._blockerMenu = null;
                    }
                    this._blockerMenu = blocker;
                    this._menuEvent = this._blockerMenu.connect(
                        'open-state-changed',
                        (menu, open) => {
                            try {
                                if(!open && this._blockerMenu !== null) {
                                    if (this._menuEvent) {
                                        this._blockerMenu.disconnect(this._menuEvent);
                                        this._menuEvent = null;
                                    }
                                    this._blockerMenu = null;
                                    this._handleMenus();
                                }
                            } catch (err) {
                                ERROR("Error in menu open-state-changed", err);
                            }
                        }
                    );
                }
            }
        } catch (err) {
            ERROR("Error in _handleMenus", err);
        }
    }

    _handleShortcut() {
        try {
            let delay_time = this._settings.get_double('shortcut-delay');
            if(this._shortcutTimeout) {
                if(this._shortcutTimeout !== true) {
                    GLib.source_remove(this._shortcutTimeout);
                }
                this._shortcutTimeout = null;
                if(delay_time < 0.05
                   || this._settings.get_boolean('shortcut-toggles')) {
                    this._intellihideBlock = false;
                    this._preventHide = false;
                    this.hide(
                        this._settings.get_double('animation-time-autohide'),
                        "shortcut"
                    );
                    return;
                }
            }

            // If setting 'shortcut-toggles' is false, repeatedly pressing the
            // shortcut should prevent the bar from hiding
            if(!this._preventHide || this._intellihideBlock) {
                this._intellihideBlock = true;
                this._preventHide = true;

                if(delay_time > 0.05) {
                    let show_time = Math.min(
                      this._settings.get_double('animation-time-autohide'),
                      Math.max(0.1, delay_time/5.0));
                    this.show(show_time, "shortcut");

                    this._shortcutTimeout = GLib.timeout_add(
                        GLib.PRIORITY_DEFAULT, delay_time*1200,
                        () => {
                            try {
                                this._preventHide = false;
                                this._intellihideBlock = false;
                                this._handleMenus();
                            } catch (err) {
                                ERROR("Error in shortcut timeout callback", err);
                            } finally {
                                this._shortcutTimeout = null;
                            }
                            return GLib.SOURCE_REMOVE;
                        }
                    );
                } else {
                    this.show(
                        this._settings.get_double('animation-time-autohide'),
                        "shortcut"
                    );
                    this._shortcutTimeout = true;
                }
            }
        } catch (err) {
            ERROR("Error in _handleShortcut", err);
        }
    }

    _disablePressureBarrier() {
        try {
            if(this._pointerListener && this._pointerWatcher) {
                try {
                    this._pointerWatcher._removeWatch(this._pointerListener);
                } catch (e) {}
                this._pointerListener = null;
            }

            if(this._panelBarrier && this._panelPressure) {
                try {
                    this._panelPressure.removeBarrier(this._panelBarrier);
                } catch (e) {}
                try {
                    this._panelBarrier.destroy();
                } catch (e) {}
                this._panelBarrier = null;
            }
        } catch (err) {
            WARN("Error in _disablePressureBarrier", err);
        }
    }

    _initPressureBarrier() {
        try {
            this._panelPressure = new Layout.PressureBarrier(
                this._settings.get_int('pressure-threshold'),
                this._settings.get_int('pressure-timeout'),
                ShellActionMode.NORMAL
            );
            this._panelPressure.connect(
                'trigger',
                (barrier) => {
                    try {
                        if (
                            Main.layoutManager.primaryMonitor?.inFullscreen
                            && !this._settings.get_boolean(
                                'mouse-sensitive-fullscreen-window'
                            )
                        ) {
                            return;
                        }
                        this.show(
                            this._settings.get_double('animation-time-autohide'),
                            "mouse-enter"
                        );
                    } catch (err) {
                        ERROR("Error in pressure barrier trigger", err);
                    }
                }
            );
            let base_y = this._getBaseY();
            let height = PanelBox.height || Main.panel.height || 32;
            let anchor_y = PanelBox.get_pivot_point()[1],
                direction = Meta.BarrierDirection.POSITIVE_Y;
            if(anchor_y < 0) {
                anchor_y -= height;
                direction = Meta.BarrierDirection.NEGATIVE_Y;
            }
            this._panelBarrier = new Meta.Barrier({
                ...(shellVersion === 45  ? { display: global.display } : { backend: global.backend }),
                x1: PanelBox.x,
                x2: PanelBox.x + PanelBox.width,
                y1: base_y - anchor_y,
                y2: base_y - anchor_y,
                directions: direction
            });
            this._panelPressure.addBarrier(this._panelBarrier);
        } catch (err) {
            ERROR("Error in _initPressureBarrier", err);
        }
    }

    _updateStaticBox() {
        try {
            DEBUG("_updateStaticBox()");
            let base_y = this._getBaseY();
            let height = PanelBox.height || Main.panel.height || 32;
            let anchor_y = PanelBox.get_pivot_point()[1];
            this._staticBox.init_rect(
                PanelBox.x, base_y - anchor_y, PanelBox.width, height
            );
            this._intellihide?.updateTargetBox(this._staticBox);
            if (this._desktopIconsUsableArea) {
                this._desktopIconsUsableArea.resetMargins();
                this._desktopIconsUsableArea.setMargins(-1, height, 0, 0, 0);
            }
        } catch (err) {
            ERROR("Error in _updateStaticBox", err);
        }
    }

    _updateHotCorner(panel_hidden) {
        try {
            let HotCorner = null;
            if (Main.layoutManager.hotCorners) {
                for(let i = 0; i < Main.layoutManager.hotCorners.length; i++){
                    let hc = Main.layoutManager.hotCorners[i];
                    if(hc){
                        HotCorner = hc;
                        break;
                    }
                }
            }
            if(HotCorner){
                let height = PanelBox.height || Main.panel.height || 32;
                if(!panel_hidden || this._settings.get_boolean('hot-corner')) {
                    HotCorner.setBarrierSize(height);
                } else {
                    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 100, function () {
                        try {
                            HotCorner.setBarrierSize(0);
                        } catch (e) {
                            ERROR("Error resetting hot corner barrier size", e);
                        }
                        return GLib.SOURCE_REMOVE;
                    });
                }
            }
        } catch (err) {
            ERROR("Error in _updateHotCorner", err);
        }
    }

    _updateSettingsHotCorner() {
        try {
            this.hide(0.1, "hot-corner-setting-changed");
        } catch (err) {
            ERROR("Error in _updateSettingsHotCorner", err);
        }
    }

    _updateSettingsMouseSensitive() {
        try {
            if(this._settings.get_boolean('mouse-sensitive')) {
                this._disablePressureBarrier();
                this._initPressureBarrier();
            } else this._disablePressureBarrier();
        } catch (err) {
            ERROR("Error in _updateSettingsMouseSensitive", err);
        }
    }

    _updateSettingsShowInOverview() {
        try {
            this._showInOverview = this._settings.get_boolean('show-in-overview');
            this._updateSearchEntryPadding();
        } catch (err) {
            ERROR("Error in _updateSettingsShowInOverview", err);
        }
    }

    _updateSearchEntryPadding() {
        try {
            const searchEntryBin = getSearchEntryBin();
            if (!searchEntryBin) return;
            if (!Main.layoutManager.primaryMonitor) return;
            const scale = Main.layoutManager.primaryMonitor.geometry_scale || 1;
            const height = PanelBox.height || Main.panel.height || 32;
            const offset = height / scale;
            searchEntryBin.set_style(
                this._showInOverview ? `padding-top: ${offset}px;` : null
            );
        } catch (err) {
            WARN("Error in _updateSearchEntryPadding", err);
        }
    }

    _updateIntellihideStatus() {
        try {
            if(this._settings.get_boolean('enable-intellihide')) {
                this._intellihideBlock = false;
                this._preventHide = false;
                this._intellihide?.enable();
            } else {
                this._intellihide?.disable();
                this._intellihideBlock = true;
                this._preventHide = false;
                this.hide(0, "init");
            }
        } catch (err) {
            ERROR("Error in _updateIntellihideStatus", err);
        }
    }

    _updatePreventHide() {
        try {
            if(this._intellihideBlock || !this._intellihide) return;

            this._preventHide = !this._intellihide.getOverlapStatus();
            let animTime = this._settings.get_double('animation-time-autohide');
            if(this._preventHide) {
                if (this._showInOverview || !Main.overview.visible)
                    this.show(animTime, "intellihide");
            } else if(!Main.overview.visible)
                this.hide(animTime, "intellihide");
        } catch (err) {
            ERROR("Error in _updatePreventHide", err);
        }
    }

    _bindUIChanges() {
        try {
            this._signalsHandler.addWithLabel("ui",
                [
                    Main.overview,
                    'showing',
                    () => {
                        try {
                            if(this._showInOverview) {
                                this.show(
                                    this._settings.get_double(
                                        'animation-time-overview'
                                    ),
                                    "showing-overview"
                                );
                            }
                        } catch (err) {
                            ERROR("Error in overview showing handler", err);
                        }
                    }
                ],
                [
                    Main.overview,
                    'hiding',
                    () => {
                        try {
                            this.hide(
                                this._settings.get_double('animation-time-overview'),
                                "hiding-overview"
                            );
                        } catch (err) {
                            ERROR("Error in overview hiding handler", err);
                        }
                    }
                ],
                [
                    Main.overview,
                    'hidden',
                    () => {
                        try {
                            this._updatePreventHide();
                        } catch (err) {
                            ERROR("Error in overview hidden handler", err);
                        }
                    }
                ],
                [
                    Main.panel,
                    'leave-event',
                    () => {
                        try {
                            this._handleMenus();
                        } catch (err) {
                            ERROR("Error in panel leave-event handler", err);
                        }
                    }
                ],
                [
                    PanelBox,
                    'notify::anchor-y',
                    () => {
                        try {
                            this._updateStaticBox();
                            this._updateSettingsMouseSensitive();
                        } catch (err) {
                            ERROR("Error in notify::anchor-y handler", err);
                        }
                    }
                ],
                [
                    PanelBox,
                    'notify::height',
                    () => {
                        try {
                            this._updateSearchEntryPadding();
                        } catch (err) {
                            ERROR("Error in notify::height handler", err);
                        }
                    }
                ],
                [
                    Main.layoutManager,
                    'monitors-changed',
                    () => {
                        try {
                            this._updateStaticBox();
                            this._updateSettingsMouseSensitive();
                            this._updateIntellihideStatus();
                        } catch (err) {
                            ERROR("Error in monitors-changed handler", err);
                        }
                    }
                ]
            );

            if (this._intellihide) {
                this._signalsHandler.addWithLabel("intellihide", [
                    this._intellihide,
                    'status-changed',
                    () => {
                        try {
                            this._updatePreventHide();
                        } catch (err) {
                            ERROR("Error in status-changed handler", err);
                        }
                    }
                ]);
            }

            try {
                Main.wm.addKeybinding("shortcut-keybind",
                    this._settings, Meta.KeyBindingFlags.NONE,
                    ShellActionMode.NORMAL,
                    this._handleShortcut.bind(this)
                );
            } catch (err) {
                ERROR("Error registering shortcut-keybind", err);
            }

            if (!PanelBox.has_allocation()) {
                let tmp_handle = PanelBox.connect("notify::allocation", () => {
                    try {
                        this._updateIntellihideStatus();
                        PanelBox.disconnect(tmp_handle);
                    } catch (err) {
                        ERROR("Error in notify::allocation handler", err);
                    }
                });
            } else {
                this._updateIntellihideStatus();
            }
        } catch (err) {
            ERROR("Error in _bindUIChanges", err);
        }

        this._bindTimeoutId = 0;
        return GLib.SOURCE_REMOVE;
    }

    _bindSettingsChanges() {
        this._signalsHandler.addWithLabel("settings",
            [
                this._settings,
                'changed::hot-corner',
                this._updateSettingsHotCorner.bind(this)
            ],
            [
                this._settings,
                'changed::mouse-sensitive',
                this._updateSettingsMouseSensitive.bind(this)
            ],
            [
                this._settings,
                'changed::pressure-timeout',
                this._updateSettingsMouseSensitive.bind(this)
            ],
            [
                this._settings,
                'changed::pressure-threshold',
                this._updateSettingsMouseSensitive.bind(this)
            ],
            [
                this._settings,
                'changed::show-in-overview',
                this._updateSettingsShowInOverview.bind(this)
            ],
            [
                this._settings,
                'changed::enable-intellihide',
                this._updateIntellihideStatus.bind(this)
            ],
            [
                this._settings,
                'changed::enable-active-window',
                this._updateIntellihideStatus.bind(this)
            ]
        );
    }

    _applyDashPolish() {
        try {
            let dash = Main.overview?.dash;
            if (dash && typeof dash._adjustIconSize === 'function') {
                this._origDashAdjustIconSize = dash._adjustIconSize;
                dash._adjustIconSize = () => {
                    try {
                        if (this._origDashAdjustIconSize) {
                            this._origDashAdjustIconSize.call(dash);
                        }
                    } catch (e) {}
                    // Refined 44px dock icon size instead of oversized 64px default
                    if (dash.iconSize > 44) {
                        dash.iconSize = 44;
                        dash.emit('icon-size-changed');
                    }
                };
                try {
                    dash._adjustIconSize();
                } catch (e) {}
            }
        } catch (err) {
            WARN("Could not apply dash size polish", err);
        }
    }

    destroy() {
        LOG("Destroying PanelVisibilityManager");
        if (this._origToggleQuickSettings && Main.panel) {
            Main.panel.toggleQuickSettings = this._origToggleQuickSettings;
            this._origToggleQuickSettings = null;
        }
        if (this._origToggleCalendar && Main.panel) {
            Main.panel.toggleCalendar = this._origToggleCalendar;
            this._origToggleCalendar = null;
        }
        if (this._origWmToggleQuickSettings && Main.wm) {
            Main.wm._toggleQuickSettings = this._origWmToggleQuickSettings;
            this._origWmToggleQuickSettings = null;
        }
        if (this._origWmToggleCalendar && Main.wm) {
            Main.wm._toggleCalendar = this._origWmToggleCalendar;
            this._origWmToggleCalendar = null;
        }
        if (this._origDashAdjustIconSize && Main.overview?.dash) {
            Main.overview.dash._adjustIconSize = this._origDashAdjustIconSize;
            this._origDashAdjustIconSize = null;
        }
        if (this._origStartSwitcher && Main.wm) {
            Main.wm._startSwitcher = this._origStartSwitcher;
            this._origStartSwitcher = null;
        }
        if (this._bindTimeoutId) {
            GLib.source_remove(this._bindTimeoutId);
            this._bindTimeoutId = 0;
        }
        if (this._shortcutTimeout && this._shortcutTimeout !== true) {
            GLib.source_remove(this._shortcutTimeout);
            this._shortcutTimeout = null;
        }
        if (this._menuEvent && this._blockerMenu) {
            try {
                this._blockerMenu.disconnect(this._menuEvent);
            } catch (err) {}
            this._menuEvent = null;
            this._blockerMenu = null;
        }
        try {
            this._intellihide?.destroy();
        } catch (err) {
            ERROR("Error destroying intellihide", err);
        }
        try {
            this._signalsHandler?.destroy();
        } catch (err) {
            ERROR("Error destroying signalsHandler", err);
        }
        try {
            Main.wm.removeKeybinding("shortcut-keybind");
        } catch (err) {
            ERROR("Error removing shortcut-keybind", err);
        }
        try {
            this._disablePressureBarrier();
        } catch (err) {
            ERROR("Error disabling pressure barrier", err);
        }
        try {
            let searchEntryBin = getSearchEntryBin();
            if (searchEntryBin) {
                searchEntryBin.style = null;
            }
        } catch (err) {
            ERROR("Error resetting searchEntryBin style", err);
        }

        try {
            if (MessageTray && MessageTray._bannerBin && this._oldEase) {
                MessageTray._bannerBin.ease = this._oldEase;
                this._oldEase = null;
            }
        } catch (err) {
            ERROR("Error restoring MessageTray bannerBin ease", err);
        }
        try {
            this.show(0, "destroy");
        } catch (err) {
            ERROR("Error in show on destroy", err);
        }

        try {
            Main.layoutManager.removeChrome(PanelBox);
            Main.layoutManager.addChrome(PanelBox, {
                affectsStruts: true,
                trackFullscreen: true
            });
        } catch (err) {
            ERROR("Error restoring PanelBox chrome", err);
        }
        try {
            this._desktopIconsUsableArea?.destroy();
            this._desktopIconsUsableArea = null;
        } catch (err) {
            ERROR("Error destroying desktopIconsUsableArea", err);
        }
    }
};
